<?php
// Database credentials
$servername = "localhost";
$username = "accessc";
$password = "abcd";
$dbname = "codedb";

// Log file path
$log_file = "/home/accessc/Documents/accessc.log";

// Open log file in append mode
$log_handle = fopen($log_file, "a");

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    fwrite($log_handle, "Connection failed: " . $conn->connect_error . "\n");
    die("Connection failed");
}

fwrite($log_handle, "Connected successfully\n");

// Check if the user exists in the database
$fname = $_GET['fname'] ?? '';
$lname = $_GET['lname'] ?? '';

fwrite($log_handle, "First name: $fname\n");
fwrite($log_handle, "Last name: $lname\n");

$query = "SELECT * FROM accessc WHERE first='$fname' AND last='$lname'";
$result = $conn->query($query);

if ($result === false) {
    fwrite($log_handle, "Error executing query: " . $conn->error . "\n");
    die("Error executing query");
} else {
    if ($result->num_rows > 0) {
        fwrite($log_handle, "User already exists in the database.\n");
        echo "User already exists in the database.";
    } else {
        fwrite($log_handle, "User does not exist in the database.\n");

        // Execute Python script and display output
        $output = array();
        exec("python3 adduser.py $fname $lname", $output);
        fwrite($log_handle, "Python script executed.\n");
        fwrite($log_handle, implode("\n", $output) . "\n");

        echo "<div style='background-color:black; color:white; padding:10px;'>";
        foreach ($output as $line) {
            echo $line . '<br>';
        }
        echo "</div>";
    }
}

// Close the connection and log file handle
$conn->close();
fclose($log_handle);

// Display the log file in real-time using tail command
echo "<pre>";
system("tail -f $log_file");
echo "</pre>";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Calendar Form</title>
    <style>
        /* center the form */
        form {
            margin: 0 auto;
            max-width: 600px;
        }
        /* enlarge the input fields */
        input[type="text"],
        input[type="time"] {
            font-size: 1.5em;
            padding: 0.5em;
            width: 100%;
        }
        /* style the submit button */
        input[type="submit"] {
            background-color: #4CAF50;
            border: none;
            color: white;
            cursor: pointer;
            font-size: 1.2em;
            margin-top: 1em;
            padding: 1em;
            width: 100%;
        }
        /* style the success message */
        p.success {
            background-color: #4CAF50;
            color: white;
            padding: 1em;
            text-align: center;
        }
        /* style the schedule table */
        table {
            border-collapse: collapse;
            margin-top: 2em;
            width: 100%;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 0.5em;
            text-align: left;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        /* style the quit button */
        .quit-button {
            background-color: #f44336;
            border: none;
            color: white;
            cursor: pointer;
            font-size: 1.2em;
            margin-top: 1em;
            padding: 1em;
            width: 100%;
            text-align: center;
        }
        /* set the background color */
        body {
            background-color: lightgreen;
        }
    </style>
</head>
<body>
    <?php
    // PHP code here...
    ?>
    <form method="post">
        <label>Note:</label>
        <input type="text" name="note" required><br><br>
        <label>Unlock Time:</label>
        <input type="time" name="utime" required><br><br>
        <label>Lock Time:</label>
        <input type="time" name="ltime" required><br><br>
        <input type="submit" name="submit" value="Schedule">
    </form>
    <?php
    // PHP code here...

    // show the quit button
    echo '<form method="get" action="menu.php">';
    echo '<button class="quit-button">Quit</button>';
    echo '</form>';
    ?>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
    <title>View Crontab</title>
</head>
<body>
    <h1>View Crontab for User "accessc"</h1>
    <?php
    $output = shell_exec('sudo -u accessc crontab -l');
    echo "<pre>$output</pre>";
    ?>
    <form action="menu.php">
        <input type="submit" value="Quit">
    </form>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
	<title>View User Info</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<style>
		body {
			background-color: lightblue;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			height: 100vh;
			margin: 0;
			padding: 0;
			font-size: 12px;
		}
		table {
			border-collapse: collapse;
			width: 100%;
		}
		th, td {
			text-align: left;
			padding: 8px;
			border-bottom: 1px solid #ddd;
		}
		th {
			background-color: #4CAF50;
			color: white;
		}
		tr:hover {
			background-color: #f5f5f5;
		}
		.quit-btn {
			background-color: red;
			color: white;
			border: none;
			padding: 12px 24px;
			text-align: center;
			text-decoration: none;
			display: inline-block;
			font-size: 16px;
			margin-top: 20px;
			cursor: pointer;
			border-radius: 5px;
		}
	</style>
</head>
<body>
	<?php
	$host = 'localhost';
	$user = 'accessc';
	$password = 'abcd';
	$dbname = 'codedb';

	$mydb = new mysqli($host, $user, $password, $dbname);

	if ($mydb->connect_error) {
	  die("Connection failed: " . $mydb->connect_error);
	}

	$sql = "SELECT * FROM accessc";
	$result = $mydb->query($sql);

	if ($result->num_rows > 0) {
	  echo "<div style='overflow-x:auto;'>";
	  echo "<table>";
	  echo "<tr><th>User ID</th><th>First Name</th><th>Last Name</th><th>Card</th><th>Creation Date</th><th>Last Access</th></tr>";
	  while($row = $result->fetch_assoc()) {
	    echo "<tr>";
	    echo "<td>" . $row["user_id"] . "</td>";
	    echo "<td>" . $row["first"] . "</td>";
	    echo "<td>" . $row["last"] . "</td>";
	    echo "<td>" . implode(", ", json_decode($row["card"], true)) . "</td>";
	    echo "<td>" . $row["creation"] . "</td>";
	    echo "<td>" . $row["access"] . "</td>";
	    echo "</tr>";
	  }
	  echo "</table>";
	  echo "</div>";
	} else {
	  echo "0 results";
	}

	$mydb->close();
	?>
	<a href="menu.php" class="quit-btn">Quit</a>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
	<title>Menu</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<style>
		body {
			background-color: lightgreen;
			text-align: center;
		}
		ul {
			padding: 0;
			list-style-type: none;
			margin: 0 auto;
			max-width: 300px;
		}
		li {
			margin-bottom: 10px;
		}
		a {
			display: block;
			padding: 10px;
			border: 2px solid black;
			background-color: white;
			text-decoration: none;
			color: black;
			font-weight: bold;
		}
	</style>
</head>
<body>
	<h1>Pi Access Control System</h1>
	<ul>
		<li><a href="add_user_name.php">Add User &amp; Cards</a></li>
		<li><a href="delete_user.php">Delete User &amp; Card</a></li>
		<li><a href="test_lock.php">Test Lock</a></li>
		<li><a href="schedules.php">Schedules</a></li>
		<li><a href="live_log.php">View Live Log</a></li>
		<li><a href="emergency.php">Emergency</a></li>
		<li><a href="view_users.php">View User Info</a></li>
		<li><a href="logout.php">Quit</a></li> <!-- Updated link to logout.php -->
	</ul>
	<p style="position: absolute; bottom: 0; width: 100%; text-align: center;">Created by Ramon Persaud</p>
</body>
</html>

<?php
// Run the Python script using exec
#$output = array();
exec("/usr/bin/python3 /home/accessc/Documents/unlock.py");

// Print the output and return value
#echo "Output:<br>";
#foreach ($output as $line) {
#    echo $line . "<br>";
#}

#echo "Return value: $return_var";
?>

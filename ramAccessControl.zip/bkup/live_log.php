<!DOCTYPE html>
<html>
<head>
	<title>Live Log Viewer</title>
	<style>
		body {
			background-color: lightgreen;
			font-size: 1.5em;
		}
		pre {
			font-size: 2em;
		}
		.quit-button {
			background-color: #f44336;
			border: none;
			color: white;
			cursor: pointer;
			font-size: 1.2em;
			margin-top: 1em;
			padding: 1em;
			width: 70%;
			text-align: center;
			margin-left: auto;
			margin-right: auto;
		}
		.center {
			display: flex;
			justify-content: center;
		}
	</style>
	<meta http-equiv="refresh" content="2">
</head>
<body>
	<h1>Live Log Viewer</h1>
	<p></p>
	<pre>
	<?php
		$log_file = '/home/accessc/Documents/accessc.log';
		$log_data = `tail -n 40 $log_file`;
		echo $log_data;
	?>
	</pre>
	<div class="center">
		<form action="menu.php">
			<input type="submit" value="Quit" class="quit-button">
		</form>
	</div>
</body>
</html>

#!/bin/bash

crontab -l | sed 's/\s\+/ /g' | tr ' ' '\t'
